/*   Page: 51
 *  Input: A temperature in degrees Fahrenheit.
 * Output: The equivalent temperature in degrees Celsius.
 * Using formula: farenheight = (9.0 / 5.0) * celsius + 32.0
 */  

import java.util.Scanner;

public class CelsiusToFahrenheit {
  public static void main(String[] args) {
    Scanner input = new Scanner(System.in);

    System.out.print("Enter a degree in Celsius: ");
    double celsius = input.nextDouble(); 

    // Convert Fahrenheit to Celsius
    double fahrenheit = 9.0 / 5 * celsius + 32.0;
    
    System.out.println("Celsius " + celsius + " is " + fahrenheit + " in Fahrenheit.");  
  }
}
