/*   Page: none
 *  Input: An amount of time in minutes.
 * Output: The equivalent time in seconds.
 */ 

import java.util.Scanner;

public class MinutesToSeconds {
  public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    
    // Prompt the user for input
    System.out.print("Enter an integer for minutes: ");
    int minutes = input.nextInt();
 
    int seconds = minutes * 60; // convert minutes to seconds
    
    System.out.println(minutes + " minutes is equivalent to: " + seconds + 
      " seconds.");  
  }
}
