/*   Page: 47
 *  Input: An amount of time in seconds.
 * Output: The equivalent time in minutes and seconds.
 */ 

import java.util.Scanner;

public class DisplayTime {
  public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    
    // Prompt the user for input
    System.out.print("Enter an integer for seconds: ");
    int seconds = input.nextInt();
 
    int minutes = seconds / 60; // Find minutes in seconds
    int remainingSeconds = seconds % 60; // Seconds remaining
    
    System.out.println(seconds + " seconds is equivalent to: " + minutes + 
      " minute(s) and " + remainingSeconds + " seconds.");  
  }
}
