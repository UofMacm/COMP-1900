/*   Page: 52
 *  Input: Calls a built-in method to obtain 
 *         the total milliseconds since midnight, Jan 1, 1970 GMT.
 * Output: The current time of day using "military time" (24-hour clock),
 *         with hours, minutes, and seconds.
 */  

public class ShowCurrentTime {
  public static void main(String[] args) {
      
    // Obtain the total milliseconds since midnight, Jan 1, 1970
    long totalMilliseconds = System.currentTimeMillis() - 6 * 60 * 60 * 1000;

    // Obtain the total seconds since midnight, Jan 1, 1970
    long totalSeconds = totalMilliseconds / 1000;

    
    // Obtain the total minutes
    long totalMinutes = totalSeconds / 60;

    // Compute the current second in the minute in the hour
    long currentSecond = totalSeconds % 60;

    
    // Obtain the total hours
    long totalHours = totalMinutes / 60;

    // Compute the current minute in the hour
    long currentMinute = totalMinutes % 60;


    // Compute the current hour
    long currentHour = totalHours % 24;

    
    // Display results
    System.out.println("Current time is " + currentHour + ":"
      + currentMinute + ":" + currentSecond + ".");
  }
}
